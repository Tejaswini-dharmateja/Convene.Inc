import { Component, OnInit } from '@angular/core';
import {QuestionClass, QuestionClasss } from '../model/survey'
import {  Router } from '@angular/router';


@Component({
  selector: 'app-survey',
  templateUrl: './survey.component.html',
  styleUrls: ['./survey.component.css']
})
export class SurveyComponent implements OnInit {

  isQuestionCardShow: boolean = false;
	totalAnswered: number = 0;
	rightAnswer: number;
	questionObj = new QuestionClass();
	questionsObj=new QuestionClasss();

	constructor( private router: Router) { }

	answerArray = [];

	allQuestions: any = [{
		"id": 1,
		"question": "1. How does Angular 4 improved error handling, when an error is caused by something in a template?",
		"a": "By enabling TypeScript's StrictNullChecks",
		"b": "By creating flattened versions of Angular modules",
		"c": "By generating source maps in terms of original template",
		"d": "None of the mentioned",
		
	},
	{
		"id": 2,
		"question": "2. The . . . . . decorator allows us to define the pipe name that is globally available for use in any template in the across application?",
		"a": "pipeName",
		"b": "pipeDeco",
		"c": "Pipe",
		"d": "None of these",
	
	},
	{
		"id": 3,
		"question": "3. Observables help you manage . . . . . . . . data?",
		"a": "Synchronous",
		"b": "Asynchronous",
		"c": "Both asynchronous & synchronous",
		"d": "None of these",
		
	},
	{
		"id": 4,
		"question": "4. How would you display a list of Employees on a webpage along with where they were in the list?",
		"a": "Loop through and print the index",
		"b": "Loop through and print the employees",
		"c": "Loop through and print the index and the employee",
		"d": "Pass both the index and the employee to a web service",
		
		
	},
	{
		"id": 5,
		"question": "5. Which of the following is not built-in pipe in Angular?",
		"a": "DatePipe",
		"b": "CurrencyPipe",
		"c": "DataPipe",
		"d": "PercentPipe",
		
	}
	
	
	];
	allQuestionss:any=[
		{
			"id":6,
		"question":"6.In AOT compilation mode, Angular web application get shipped with angular compiler along with website content in browser.",
		"a":"True",
		"b":"False"
		},
		{
			"id":7,
			"question":"7.Async Pipe subscribes to observer and update expression whenever there is data sent from observer.",
			"a":"True",
			"b":"False"
		}

	]

	/**Method call on submit the test */
	Survey() {
		alert(JSON.stringify(this.allQuestions))
		alert(JSON.stringify(this.allQuestionss))

		alert('Successfully completed')
		

		// this.rightAnswer = 0;
		// this.totalAnswered = 0;
		// for (let i = 0; i < this.allQuestions.length; i++) {
		// 	if ("selected" in this.allQuestions[i] && (this.allQuestions[i]["selected"] != null)) {
		// 		this.totalAnswered++;
		// 		if (this.allQuestions[i]["selected"] == this.allQuestions[i]["answer"]) {
		// 			this.rightAnswer++;
		// 		}
		// 	}

		// }
		
		//this.submitModal.show();
		
	}

	startSurvey() {
		for (let i = 0; i < this.allQuestions.length; i++) {	
			if ("selected" in this.allQuestions[i]) {
				delete this.allQuestions[i]["selected"];
			}


		}
		this.isQuestionCardShow = true;

	}
	HomePage() {
		this.isQuestionCardShow = false;
	}

  ngOnInit() {
  }

}
